# -*- coding: utf-8 -*-
from openerp import http

# class ReportStockCard(http.Controller):
#     @http.route('/report_stock_card/report_stock_card/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/report_stock_card/report_stock_card/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('report_stock_card.listing', {
#             'root': '/report_stock_card/report_stock_card',
#             'objects': http.request.env['report_stock_card.report_stock_card'].search([]),
#         })

#     @http.route('/report_stock_card/report_stock_card/objects/<model("report_stock_card.report_stock_card"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('report_stock_card.object', {
#             'object': obj
#         })