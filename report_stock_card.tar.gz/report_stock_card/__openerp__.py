# -*- coding: utf-8 -*-
{
    'name': "report_stock_card",
    'summary': """
        Stock Card Report to PDF
        """,
    'description': """
        Stock Card can be used to controlling product stock traffic and
        in this module, report would be print into PDF format

    """,
    'author': "Artsys Integrasi Solusindo",
    'website': "http:/artsys.id",
    'category': 'Inventory',
    'version': '1.0',
    'depends': ['base', 'stock', 'product'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'wizards/wizard_stock_card_view.xml',
        'views/view_report_stock_card.xml',
        'stock_card_report.xml'
    ],
    'demo': [
        'demo/demo.xml',
    ],
    'price': 149.99,
    'currency': 'EUR',
}