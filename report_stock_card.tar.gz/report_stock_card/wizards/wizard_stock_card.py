##############################################################################
# **************
#    PT. Artsys (Artsys Integrasi Solusiondo)
#    Copyright (C) 2016 Artsys (<http://artsys.id>).
#    Jakarta, Indonesia
#    Programmer : Dhaman (Chief Technical Officer)
#    Date : 2016-04-20
# **************
##############################################################################


from openerp import models, fields, api

class WizardStockCard(models.TransientModel):
    _name = 'wizard.stock_card'
    _description = 'Wizard Report Stock Card'

    def _default_company_id(self, cr, uid, context={}):
        obj_user = self.pool.get('res.users')
        user = obj_user.browse(cr, uid, [uid])[0]
        return user.company_id and user.company_id.id or False

    company_id = fields.Many2one('res.company', string="Company", required=True)
    product_id = fields.Many2one('product.product',string="Product", required=True)
    date_start = fields.Date(string="Start Date", required=True)
    date_end = fields.Date(string="End Date", required=True)
    location_id = fields.Many2one('stock.location',string="Location", required=True,
                                  domain="[('company_id','=',company_id)]")

    def button_print_report_stock_card(self, cr, uid, ids, context=None):
        if context is None:
            context = {}
        data = self.read(cr, uid, ids, context=context)[0]
        datas = {
            'ids': context.get('active_ids', []),
            'model': 'product_product',
            'form': data
        }
        datas['form']['ids'] = datas['ids']
        return self.pool['report'].get_action(cr, uid, [], 'stock.report_stock_card', data=datas, context=context)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
