##############################################################################
# **************
#    PT. Artsys (Artsys Integrasi Solusiondo)
#    Copyright (C) 2016 Artsys (<http://artsys.id>).
#    Jakarta, Indonesia
#    Programmer : Dhaman (Chief Technical Officer)
#    Date : 2016-04-20
#    Filename : Generate Data Report for Stock Card Report
# **************
##############################################################################

import time
from openerp.osv import osv
from openerp.report import report_sxw

class report_stock_card(report_sxw.rml_parse):

    def __init__(self, cr, uid, name, context):
        super(report_stock_card, self).__init__(cr, uid, name, context=context)

        self.localcontext.update({
            'time': time,
            'get_product_info': self._get_product_info,
            'row_stock_card': self._row_stock_card,
            'beginning_balance': self._beginning_balance,
        })

    def _get_product_info(self, product_id):
        sql = """
            select
                a.default_code 		as code
                , a.name_template 	as product_name
                , c.name 		as uom
            from product_product a
            left outer join product_template b
            on a.product_tmpl_id=b.id
            left outer join product_uom c
            on b.uom_id=c.id
            where a.id=""" + str(product_id) + """
        """
        self.cr.execute(sql)
        res = self.cr.fetchone()
        return res

    def _row_stock_card(self, product_id, date_from, date_to, company_id, location_id):
        data = {}
        sql = """
            select
                f.name		as wh_location,
                d.default_code	as product_code,
                d.name_template	as product_name,
                c.name		as uom,
                a.date::date		as trans_date,
                e.name		as picking,
                a.source		as description,
                CASE WHEN quantity>0 THEN a.quantity
                     ELSE 0
                END			as stock_in,
                CASE WHEN quantity<0 THEN abs(a.quantity)
                     ELSE 0
                END			as stock_out,
                a.price_unit_on_quant,
                CASE WHEN quantity>0 THEN a.quantity*a.price_unit_on_quant
                     ELSE 0
                END			as value_in,
                CASE WHEN quantity<0 THEN abs(a.quantity)*a.price_unit_on_quant
                     ELSE 0
                END			as value_out

            from stock_history 		as a
            left join stock_move 	as b on a.move_id=b.id
            left join product_uom 	as c on b.product_uom=c.id
            left join product_product 	as d on a.product_id=d.id
            left join stock_picking	as e on b.picking_id=e.id
            left join stock_location	as f on a.location_id=f.id
            left join product_template	as g on d.product_tmpl_id=g.id
            where a.date >= %s
                and a.date <= %s
                and a.product_id=%s
                and a.company_id=%s
                and a.location_id=%s
            order by a.location_id,a.product_id,a.date
        """
        self.cr.execute(sql, (date_from, date_to, product_id, company_id, location_id))
        data = self.cr.dictfetchall()
        return data

    def _beginning_balance(self, product_id, date_from, company_id, location_id):
        sql = """
            select
                coalesce(sum(a.quantity),0)		as beginning_balance_qty
                ,coalesce((sum(a.quantity*a.price_unit_on_quant)/sum(a.quantity)),0) as price
                ,coalesce(sum(a.quantity*a.price_unit_on_quant),0)	as beginning_balance_value
            from stock_history a
            where a.date <= %s
            and a.product_id=%s
            and a.company_id=%s
            and a.location_id=%s
        """
        self.cr.execute(sql, (date_from, product_id, company_id, location_id))
        res = self.cr.fetchone()
        return res


class report_product_stock_card(osv.AbstractModel):
    _name = 'report.stock.report_stock_card'
    _inherit = 'report.abstract_report'
    _template = 'stock.report_stock_card'
    _wrapped_report_class = report_stock_card